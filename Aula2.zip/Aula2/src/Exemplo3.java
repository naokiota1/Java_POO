
public class Exemplo3 {
	public static void main(String[] args) {
		String nome = "Guilherme";
		String sobrenome = "Ota";
		int idade = 3;
		int anoNascimento = 2019;
		// O aluno XXXX XXXX tem 3 anos e nasceu em 2019
		
		System.out.println("O aluno " + nome + " " + sobrenome + " tem " + idade + 
		" anos e nasceu em "+ anoNascimento );
	}
	
}
