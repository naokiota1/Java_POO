
public class Exemplo1 {
	public static void main(String[] args) {
		System.out.println("Ol� mundo!");
		System.out.println("Ol� Universidade");
		
		System.out.print("Nome");
		System.out.print("Sobrenome");
	}
}
