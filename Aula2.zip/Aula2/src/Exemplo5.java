
public class Exemplo5 {
 public static void main(String[] args) {
	 int numInteiro =10;
	 float numFrac = 50.8f;
	 
	 //Soma
	 System.out.println(numInteiro + numInteiro);
	 //Subtra��o
	 System.out.println(numInteiro - numInteiro);
	 //Multiplica��o
	 System.out.println(numInteiro * numInteiro);
	 //Divis�o
	 System.out.println(numInteiro / numInteiro);
	 
	 //Int + Double | *quest�o pode cair na prova
	 System.out.println(numInteiro + numFrac);
	 
	 
	 //Soma de char
	 //Resultado da soma na tabela ASCII
	 char letra1 = 'D';
	 char letra2 = 'I';
	 
	 System.out.println(letra1 + letra2);
	 
	 //String | N�o � tipo de dado primitivo
	 String letraA = "A";
	 String letraB = "B";
	 System.out.println(letraA + letraB);
 }
}
