//Declara��o de vari�veis
//Tipos de dados primitivos e Strings
public class Exemplo2 {

	public static void main(String[] args) {
		String nome = "Guilherme";
		String sobrenome = "Ota";
		String nomeCompleto = nome +" "+ sobrenome;
		//Concatenar informa��es
		System.out.println(nome +" "+ sobrenome);
		System.out.println(nomeCompleto);
	}

}
